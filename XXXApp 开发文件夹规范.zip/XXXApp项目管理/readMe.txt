Requirement（-需求相关文档）
  Design（-设计相关）
  Planning&Log （计划，日志，会议记录）
  Test（集成测试，系统测试，测试报告，buglist）
  Study（学习资料，相关技术demo）
  Deployment/Publish（发布部署）
  Source （源代码以及单元测试）
     -Android_Keystore(签名文件以及签名信息)
     -相关联项目工程
     -project_properties_setting
          -SDK生产
          -SDK测试
  Help（帮助文档）
  ReadMe.txt（说明各个文件夹作用）
